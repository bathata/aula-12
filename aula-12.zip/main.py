__author__ = 'Thauane'
print('=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n')
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 import math
print(math.factorial(6))


#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

#praticando dicionários]

#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

classe = {'anna' : 4.5,
         'Beatriz': 6.5
         'Geraldo': 1.00
         'José': 10.00
        'Maria': 9.5}

notas = classe.values()
media = sum(notas)/5
print('A média da classe é ',media)

print('=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n')
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

dic = {'salgado' : 3.50,
      'lanche': 6.50,
      'suco': 3.00,
      'refrigerante': 3.50,
      'doce': 1.00}
print(dic)

D = { 'arroz': 17.30, 'feijão' : 12.50, 'carne' : 23.90, 'alface' : 3.40}
print(D)
D['carne'] = 25.00
D['tomate'] = 8.80
print(D)

print('=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n')
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

#negócinho de tuplas e desempacotamento

#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
T = (10, 20, 30, 40, 50)
a,b,c,d,e = T
print('a = ',a,'b = ',b)
print('c = ',c,'d = ',d)
print('\nd + e =',d+e)

print('=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n')
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

#Praticando as listas :D

#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
L = [5, 7, 2, 9, 4, 1, 3]
print('Lista = ',L)
print('\nO tamanho da lista é: ',len(L))
print('\nO maior elemento da lista é: ',max(L))
print('\nO menor elemento da lista é: ',min(L))
print('\nA soms dos elementos da lista é: ',sum(L))
L.sort
print('\nLista em ordem crescente: ',L)
L.reverse
print('\nLista em ordem decrescente: ',L)
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
L = [3, 'abacate', 9.7, [5, 6, 3], 'Python', (3, 'j')]
print(L[2])
print(L[3])
print(L[3][1])
print(L[1:4])
print(L[2:])
print(L[:4])
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
L = [3, 'abacate', 9.7, [5, 6, 3], 'Python', (3, 'j')]
print(L[2])
print(L[3])
print(L[3][1])
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=